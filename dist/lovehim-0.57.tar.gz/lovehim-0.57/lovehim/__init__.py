from .get_verse import generate_verse

__version__ = "0.57"
